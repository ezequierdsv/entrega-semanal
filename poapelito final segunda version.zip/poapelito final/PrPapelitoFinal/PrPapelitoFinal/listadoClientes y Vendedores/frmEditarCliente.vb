﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmEditarCliente

    Private Sub ClientesBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.ClientesBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.GFacHojillaDataSet)

    End Sub

    Private Sub frmEditarCliente_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'GFacHojillaDataSet.Clientes' Puede moverla o quitarla según sea necesario.
        Me.ClientesTableAdapter.Fill(Me.GFacHojillaDataSet.Clientes)

    End Sub

    Private Sub btnEditar_Click(sender As Object, e As EventArgs) Handles btnEditar.Click

        Try
            'Declaración de Variables. Cadena de conexión a la Base de Datos
            Dim conex As New SqlConnection(("Data Source=DESKTOP-5G7MSS4\SQLEXPRESS;Initial Catalog=GFacHojilla;Integrated Security=SSPI;"))
            Dim cmd As New SqlCommand("ModificarClientee", conex) 'Nombre del Procedimiento
            'Llamando al Procedimiento Almacenado
            cmd.CommandType = CommandType.StoredProcedure
            'Pasamos los Parámetros necesarios al Procedimiento
            cmd.Parameters.Add("@RUT", SqlDbType.VarChar).Value = Val(txtRut.Text)
            cmd.Parameters.Add("@Nombre", SqlDbType.VarChar).Value = txtNombre.Text
            cmd.Parameters.Add("@IdCliente", SqlDbType.VarChar).Value = Val(txtIdCliente.Text)
            cmd.Parameters.Add("@Teléfono", SqlDbType.VarChar).Value = Val(txtTelefono.Text)
            cmd.Parameters.Add("@Dirección", SqlDbType.VarChar).Value = txtDireccion.Text
            'Abrimos la Conexión
            conex.Open()
            'Ejecutamos la Consulta
            cmd.ExecuteNonQuery()
            'Cerramos la Conexión
            conex.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message) 'Mensaje en caso de Error
        End Try

    End Sub
End Class