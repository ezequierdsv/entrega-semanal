﻿Partial Class GFacHojillaDataSet1
End Class

Namespace PrPapelitoFinal.GFacHojillaDataSet1TableAdapters

    Partial Public Class MercaderíaTableAdapter
    End Class
End Namespace
