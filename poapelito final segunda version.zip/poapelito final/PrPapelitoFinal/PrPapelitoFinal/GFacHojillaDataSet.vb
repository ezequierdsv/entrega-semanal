﻿Partial Class GFacHojillaDataSet
End Class

Namespace GFacHojillaDataSetTableAdapters

    Partial Public Class ClientesTableAdapter
    End Class
End Namespace
