﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class btnAgregar
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IdEntregaLabel As System.Windows.Forms.Label
        Dim IdVendedorLabel As System.Windows.Forms.Label
        Dim IdHojillaLabel As System.Windows.Forms.Label
        Dim FechaLabel As System.Windows.Forms.Label
        Dim CantCajasLabel As System.Windows.Forms.Label
        Dim ImporteTotalLabel As System.Windows.Forms.Label
        Me.GFacHojillaDataSet = New PrPapelitoFinal.GFacHojillaDataSet()
        Me.EntregasBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EntregasTableAdapter = New PrPapelitoFinal.GFacHojillaDataSetTableAdapters.EntregasTableAdapter()
        Me.TableAdapterManager = New PrPapelitoFinal.GFacHojillaDataSetTableAdapters.TableAdapterManager()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.txtIdEntrega = New System.Windows.Forms.TextBox()
        Me.txtIdVende = New System.Windows.Forms.TextBox()
        Me.txtIdHojillas = New System.Windows.Forms.TextBox()
        Me.FechaDate = New System.Windows.Forms.DateTimePicker()
        Me.txtCantCajas = New System.Windows.Forms.TextBox()
        Me.txtImportToal = New System.Windows.Forms.TextBox()
        Me.Datos = New System.Windows.Forms.GroupBox()
        Me.lblIdVendedor = New System.Windows.Forms.Label()
        Me.btnBuscar2 = New System.Windows.Forms.Button()
        Me.btnBuscar1 = New System.Windows.Forms.Button()
        Me.btnMostrar = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.btnEliminar = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        IdEntregaLabel = New System.Windows.Forms.Label()
        IdVendedorLabel = New System.Windows.Forms.Label()
        IdHojillaLabel = New System.Windows.Forms.Label()
        FechaLabel = New System.Windows.Forms.Label()
        CantCajasLabel = New System.Windows.Forms.Label()
        ImporteTotalLabel = New System.Windows.Forms.Label()
        CType(Me.GFacHojillaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EntregasBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Datos.SuspendLayout()
        Me.SuspendLayout()
        '
        'IdEntregaLabel
        '
        IdEntregaLabel.AutoSize = True
        IdEntregaLabel.Location = New System.Drawing.Point(19, 22)
        IdEntregaLabel.Name = "IdEntregaLabel"
        IdEntregaLabel.Size = New System.Drawing.Size(59, 13)
        IdEntregaLabel.TabIndex = 1
        IdEntregaLabel.Text = "Id Entrega:"
        '
        'IdVendedorLabel
        '
        IdVendedorLabel.AutoSize = True
        IdVendedorLabel.Location = New System.Drawing.Point(19, 55)
        IdVendedorLabel.Name = "IdVendedorLabel"
        IdVendedorLabel.Size = New System.Drawing.Size(68, 13)
        IdVendedorLabel.TabIndex = 3
        IdVendedorLabel.Text = "Id Vendedor:"
        '
        'IdHojillaLabel
        '
        IdHojillaLabel.AutoSize = True
        IdHojillaLabel.Location = New System.Drawing.Point(19, 89)
        IdHojillaLabel.Name = "IdHojillaLabel"
        IdHojillaLabel.Size = New System.Drawing.Size(50, 13)
        IdHojillaLabel.TabIndex = 5
        IdHojillaLabel.Text = "Id Hojilla:"
        '
        'FechaLabel
        '
        FechaLabel.AutoSize = True
        FechaLabel.Location = New System.Drawing.Point(365, 34)
        FechaLabel.Name = "FechaLabel"
        FechaLabel.Size = New System.Drawing.Size(40, 13)
        FechaLabel.TabIndex = 7
        FechaLabel.Text = "Fecha:"
        '
        'CantCajasLabel
        '
        CantCajasLabel.AutoSize = True
        CantCajasLabel.Location = New System.Drawing.Point(365, 59)
        CantCajasLabel.Name = "CantCajasLabel"
        CantCajasLabel.Size = New System.Drawing.Size(61, 13)
        CantCajasLabel.TabIndex = 9
        CantCajasLabel.Text = "Cant Cajas:"
        '
        'ImporteTotalLabel
        '
        ImporteTotalLabel.AutoSize = True
        ImporteTotalLabel.Location = New System.Drawing.Point(365, 85)
        ImporteTotalLabel.Name = "ImporteTotalLabel"
        ImporteTotalLabel.Size = New System.Drawing.Size(72, 13)
        ImporteTotalLabel.TabIndex = 11
        ImporteTotalLabel.Text = "Importe Total:"
        '
        'GFacHojillaDataSet
        '
        Me.GFacHojillaDataSet.DataSetName = "GFacHojillaDataSet"
        Me.GFacHojillaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EntregasBindingSource
        '
        Me.EntregasBindingSource.DataMember = "Entregas"
        Me.EntregasBindingSource.DataSource = Me.GFacHojillaDataSet
        '
        'EntregasTableAdapter
        '
        Me.EntregasTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ClientesTableAdapter = Nothing
        Me.TableAdapterManager.EntregasTableAdapter = Me.EntregasTableAdapter
        Me.TableAdapterManager.MercaderíaTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = PrPapelitoFinal.GFacHojillaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.Usuarios1TableAdapter = Nothing
        Me.TableAdapterManager.UsuariosTableAdapter = Nothing
        Me.TableAdapterManager.VendedorTableAdapter = Nothing
        Me.TableAdapterManager.VentasTableAdapter = Nothing
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(159, 157)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(641, 275)
        Me.DataGridView1.TabIndex = 1
        '
        'txtIdEntrega
        '
        Me.txtIdEntrega.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EntregasBindingSource, "IdEntrega", True))
        Me.txtIdEntrega.Location = New System.Drawing.Point(95, 19)
        Me.txtIdEntrega.Name = "txtIdEntrega"
        Me.txtIdEntrega.Size = New System.Drawing.Size(107, 20)
        Me.txtIdEntrega.TabIndex = 2
        '
        'txtIdVende
        '
        Me.txtIdVende.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EntregasBindingSource, "IdVendedor", True))
        Me.txtIdVende.Location = New System.Drawing.Point(95, 52)
        Me.txtIdVende.Name = "txtIdVende"
        Me.txtIdVende.Size = New System.Drawing.Size(107, 20)
        Me.txtIdVende.TabIndex = 4
        '
        'txtIdHojillas
        '
        Me.txtIdHojillas.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EntregasBindingSource, "IdHojilla", True))
        Me.txtIdHojillas.Location = New System.Drawing.Point(95, 86)
        Me.txtIdHojillas.Name = "txtIdHojillas"
        Me.txtIdHojillas.Size = New System.Drawing.Size(107, 20)
        Me.txtIdHojillas.TabIndex = 6
        '
        'FechaDate
        '
        Me.FechaDate.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.EntregasBindingSource, "Fecha", True))
        Me.FechaDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.FechaDate.Location = New System.Drawing.Point(443, 30)
        Me.FechaDate.Name = "FechaDate"
        Me.FechaDate.Size = New System.Drawing.Size(99, 20)
        Me.FechaDate.TabIndex = 8
        '
        'txtCantCajas
        '
        Me.txtCantCajas.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EntregasBindingSource, "CantCajas", True))
        Me.txtCantCajas.Location = New System.Drawing.Point(443, 56)
        Me.txtCantCajas.Name = "txtCantCajas"
        Me.txtCantCajas.Size = New System.Drawing.Size(99, 20)
        Me.txtCantCajas.TabIndex = 10
        '
        'txtImportToal
        '
        Me.txtImportToal.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EntregasBindingSource, "ImporteTotal", True))
        Me.txtImportToal.Location = New System.Drawing.Point(443, 82)
        Me.txtImportToal.Name = "txtImportToal"
        Me.txtImportToal.Size = New System.Drawing.Size(99, 20)
        Me.txtImportToal.TabIndex = 12
        '
        'Datos
        '
        Me.Datos.Controls.Add(Me.lblIdVendedor)
        Me.Datos.Controls.Add(Me.btnBuscar2)
        Me.Datos.Controls.Add(Me.btnBuscar1)
        Me.Datos.Controls.Add(IdEntregaLabel)
        Me.Datos.Controls.Add(FechaLabel)
        Me.Datos.Controls.Add(Me.FechaDate)
        Me.Datos.Controls.Add(Me.txtIdHojillas)
        Me.Datos.Controls.Add(CantCajasLabel)
        Me.Datos.Controls.Add(IdHojillaLabel)
        Me.Datos.Controls.Add(Me.txtCantCajas)
        Me.Datos.Controls.Add(Me.txtIdVende)
        Me.Datos.Controls.Add(ImporteTotalLabel)
        Me.Datos.Controls.Add(Me.txtIdEntrega)
        Me.Datos.Controls.Add(Me.txtImportToal)
        Me.Datos.Controls.Add(IdVendedorLabel)
        Me.Datos.Location = New System.Drawing.Point(159, 23)
        Me.Datos.Name = "Datos"
        Me.Datos.Size = New System.Drawing.Size(571, 128)
        Me.Datos.TabIndex = 13
        Me.Datos.TabStop = False
        Me.Datos.Text = "Datos:"
        '
        'lblIdVendedor
        '
        Me.lblIdVendedor.AutoSize = True
        Me.lblIdVendedor.Location = New System.Drawing.Point(290, 56)
        Me.lblIdVendedor.Name = "lblIdVendedor"
        Me.lblIdVendedor.Size = New System.Drawing.Size(13, 13)
        Me.lblIdVendedor.TabIndex = 16
        Me.lblIdVendedor.Text = "0"
        '
        'btnBuscar2
        '
        Me.btnBuscar2.Location = New System.Drawing.Point(208, 84)
        Me.btnBuscar2.Name = "btnBuscar2"
        Me.btnBuscar2.Size = New System.Drawing.Size(75, 23)
        Me.btnBuscar2.TabIndex = 15
        Me.btnBuscar2.Text = "Buscar"
        Me.btnBuscar2.UseVisualStyleBackColor = True
        '
        'btnBuscar1
        '
        Me.btnBuscar1.Location = New System.Drawing.Point(209, 50)
        Me.btnBuscar1.Name = "btnBuscar1"
        Me.btnBuscar1.Size = New System.Drawing.Size(75, 23)
        Me.btnBuscar1.TabIndex = 14
        Me.btnBuscar1.Text = "Buscar"
        Me.btnBuscar1.UseVisualStyleBackColor = True
        '
        'btnMostrar
        '
        Me.btnMostrar.Location = New System.Drawing.Point(43, 157)
        Me.btnMostrar.Name = "btnMostrar"
        Me.btnMostrar.Size = New System.Drawing.Size(75, 23)
        Me.btnMostrar.TabIndex = 15
        Me.btnMostrar.Text = "Mostrar"
        Me.btnMostrar.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(43, 217)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 16
        Me.Button2.Text = "Agregar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'btnEliminar
        '
        Me.btnEliminar.Location = New System.Drawing.Point(43, 283)
        Me.btnEliminar.Name = "btnEliminar"
        Me.btnEliminar.Size = New System.Drawing.Size(75, 23)
        Me.btnEliminar.TabIndex = 17
        Me.btnEliminar.Text = "Eliminar"
        Me.btnEliminar.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(43, 362)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 18
        Me.Button4.Text = "Salir"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'btnAgregar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(812, 499)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.btnEliminar)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnMostrar)
        Me.Controls.Add(Me.Datos)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "btnAgregar"
        Me.Text = "frmVentas"
        CType(Me.GFacHojillaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EntregasBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Datos.ResumeLayout(False)
        Me.Datos.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GFacHojillaDataSet As GFacHojillaDataSet
    Friend WithEvents EntregasBindingSource As BindingSource
    Friend WithEvents EntregasTableAdapter As GFacHojillaDataSetTableAdapters.EntregasTableAdapter
    Friend WithEvents TableAdapterManager As GFacHojillaDataSetTableAdapters.TableAdapterManager
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents txtIdEntrega As TextBox
    Friend WithEvents txtIdVende As TextBox
    Friend WithEvents txtIdHojillas As TextBox
    Friend WithEvents FechaDate As DateTimePicker
    Friend WithEvents txtCantCajas As TextBox
    Friend WithEvents txtImportToal As TextBox
    Friend WithEvents Datos As GroupBox
    Friend WithEvents btnBuscar2 As Button
    Friend WithEvents btnBuscar1 As Button
    Friend WithEvents btnMostrar As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents btnEliminar As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents lblIdVendedor As Label
End Class
