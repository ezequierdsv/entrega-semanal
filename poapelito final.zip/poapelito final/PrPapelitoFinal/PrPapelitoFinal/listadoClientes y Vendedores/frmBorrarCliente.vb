﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmBorrarCliente
    Private dv As New DataView
    Private Sub ClientesBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.ClientesBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.GFacHojillaDataSet)

    End Sub

    Private Sub frmBorrarCliente_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'GFacHojillaDataSet.Clientes' Puede moverla o quitarla según sea necesario.
        Me.ClientesTableAdapter.Fill(Me.GFacHojillaDataSet.Clientes)

    End Sub

    Private Sub btnMostrar_Click(sender As Object, e As EventArgs) Handles btnMostrar.Click
        Try
            'Declarando variables (Cadena de Conexión, Adaptador de Datos y DataSet)
            Dim conex As New SqlConnection("Data Source=DESKTOP-5G7MSS4\SQLEXPRESS;Initial Catalog=GFacHojilla;Integrated Security=SSPI;")
            'Consulta a la Tabla de la B.D.
            Dim da As New SqlDataAdapter("Select * From Clientes", conex)
            Dim ds As New DataSet
            'Cargamos la Tabla de Datos dentro del DataGridView
            da.Fill(ds)
            dv.Table = ds.Tables(0)
            DataGridView1.DataSource = dv
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
    End Sub
    Private Sub btnBorrar_Click(sender As Object, e As EventArgs) Handles btnBorrar.Click
        Dim Respuesta As Integer
        'Pedir Confirmación al usuario para Borrar definitivo
        Respuesta = MessageBox.Show("¿Está seguro(a) que desea Eliminar este Alumno?",
 "Registro de Alumnos", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation)
        'Si responde SI, lo borramos
        If (Respuesta = DialogResult.Yes) Then

            'Verificar que las cajas de texto NO ESTEN VACIAS
            If txtIdCliente.Text = "" Then
                'Mensaje de Error
                MessageBox.Show("Debe escribir el Número de Cédula del Alumno. Revise", "FALTAN

DATOS", MessageBoxButtons.OK, MessageBoxIcon.Error)

            Else
                Try
                    'Declaración de Variables. Cadena de conexión a la Base de Datos
                    Dim conex As New SqlConnection("Data Source=DESKTOP-5G7MSS4\SQLEXPRESS;Initial Catalog=GFacHojilla;Integrated Security=SSPI;")

                    Dim cmd As New SqlCommand("BorrarCliente", conex)
                    'Llamado al Procedimiento Almacenado
                    cmd.CommandType = CommandType.StoredProcedure
                    'Pasamos el Parámetro necesario al Procedimiento

                    cmd.Parameters.Add("@Original_IdCliente", SqlDbType.VarChar).Value = Val(txtIdCliente.Text)

                    'Abrimos la Conexión
                    conex.Open()
                    'Ejecutamos la Consulta
                    cmd.ExecuteNonQuery()
                    Me.ClientesTableAdapter.Fill(Me.GFacHojillaDataSet.Clientes)
                    'Cerramos la Conexión
                    conex.Close()
                Catch ex As Exception
                    MessageBox.Show(ex.Message) 'Mensaje en caso de Error

                End Try
            End If
        End If
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub
End Class