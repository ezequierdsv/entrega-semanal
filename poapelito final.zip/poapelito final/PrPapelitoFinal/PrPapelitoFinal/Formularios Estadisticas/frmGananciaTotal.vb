﻿Public Class frmGananciaTotal

End Class