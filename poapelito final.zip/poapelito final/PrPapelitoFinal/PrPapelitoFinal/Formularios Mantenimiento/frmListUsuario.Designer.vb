﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmListUsuario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim NombreLabel As System.Windows.Forms.Label
        Dim IdUsuarioLabel As System.Windows.Forms.Label
        Dim ContraseñaLabel As System.Windows.Forms.Label
        Dim ApellidosLabel As System.Windows.Forms.Label
        Dim NombreDeUsuarioLabel As System.Windows.Forms.Label
        Dim IdVendedorLabel As System.Windows.Forms.Label
        Me.btnAplicar = New System.Windows.Forms.Button()
        Me.gbxOperaciones = New System.Windows.Forms.GroupBox()
        Me.rbtEliminar = New System.Windows.Forms.RadioButton()
        Me.rbtModificar = New System.Windows.Forms.RadioButton()
        Me.rbtAgregar = New System.Windows.Forms.RadioButton()
        Me.rbtListado = New System.Windows.Forms.RadioButton()
        Me.dgvUsuarios = New System.Windows.Forms.DataGridView()
        Me.txtNombres = New System.Windows.Forms.TextBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtApellidos = New System.Windows.Forms.TextBox()
        Me.txtNombUsuario = New System.Windows.Forms.TextBox()
        Me.gbxDatosUsuario = New System.Windows.Forms.GroupBox()
        Me.btnMuestraOculta = New System.Windows.Forms.Button()
        Me.txtIdVendedor = New System.Windows.Forms.TextBox()
        Me.txtTotalUsuarios = New System.Windows.Forms.TextBox()
        Me.cboTAcceso = New System.Windows.Forms.ComboBox()
        Me.btnActualizar = New System.Windows.Forms.Button()
        Me.btnEliminar = New System.Windows.Forms.Button()
        Me.btnGuardar = New System.Windows.Forms.Button()
        Me.btnOperacion = New System.Windows.Forms.Button()
        Me.btnTerminar = New System.Windows.Forms.Button()
        Me.lblTexto = New System.Windows.Forms.Label()
        Me.UsuariosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GFacHojillaDataSet = New PrPapelitoFinal.GFacHojillaDataSet()
        Me.UsuariosTableAdapter = New PrPapelitoFinal.GFacHojillaDataSetTableAdapters.UsuariosTableAdapter()
        Me.TableAdapterManager = New PrPapelitoFinal.GFacHojillaDataSetTableAdapters.TableAdapterManager()
        Me.Usuarios1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Usuarios1TableAdapter = New PrPapelitoFinal.GFacHojillaDataSetTableAdapters.Usuarios1TableAdapter()
        NombreLabel = New System.Windows.Forms.Label()
        IdUsuarioLabel = New System.Windows.Forms.Label()
        ContraseñaLabel = New System.Windows.Forms.Label()
        ApellidosLabel = New System.Windows.Forms.Label()
        NombreDeUsuarioLabel = New System.Windows.Forms.Label()
        IdVendedorLabel = New System.Windows.Forms.Label()
        Me.gbxOperaciones.SuspendLayout()
        CType(Me.dgvUsuarios, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbxDatosUsuario.SuspendLayout()
        CType(Me.UsuariosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GFacHojillaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Usuarios1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'NombreLabel
        '
        NombreLabel.AutoSize = True
        NombreLabel.Location = New System.Drawing.Point(34, 86)
        NombreLabel.Name = "NombreLabel"
        NombreLabel.Size = New System.Drawing.Size(47, 13)
        NombreLabel.TabIndex = 15
        NombreLabel.Text = "Nombre:"
        '
        'IdUsuarioLabel
        '
        IdUsuarioLabel.AutoSize = True
        IdUsuarioLabel.Location = New System.Drawing.Point(236, 37)
        IdUsuarioLabel.Name = "IdUsuarioLabel"
        IdUsuarioLabel.Size = New System.Drawing.Size(58, 13)
        IdUsuarioLabel.TabIndex = 17
        IdUsuarioLabel.Text = "Id Usuario:"
        '
        'ContraseñaLabel
        '
        ContraseñaLabel.AutoSize = True
        ContraseñaLabel.Location = New System.Drawing.Point(288, 129)
        ContraseñaLabel.Name = "ContraseñaLabel"
        ContraseñaLabel.Size = New System.Drawing.Size(64, 13)
        ContraseñaLabel.TabIndex = 19
        ContraseñaLabel.Text = "Contraseña:"
        '
        'ApellidosLabel
        '
        ApellidosLabel.AutoSize = True
        ApellidosLabel.Location = New System.Drawing.Point(288, 90)
        ApellidosLabel.Name = "ApellidosLabel"
        ApellidosLabel.Size = New System.Drawing.Size(52, 13)
        ApellidosLabel.TabIndex = 21
        ApellidosLabel.Text = "Apellidos:"
        '
        'NombreDeUsuarioLabel
        '
        NombreDeUsuarioLabel.AutoSize = True
        NombreDeUsuarioLabel.Location = New System.Drawing.Point(34, 125)
        NombreDeUsuarioLabel.Name = "NombreDeUsuarioLabel"
        NombreDeUsuarioLabel.Size = New System.Drawing.Size(103, 13)
        NombreDeUsuarioLabel.TabIndex = 23
        NombreDeUsuarioLabel.Text = "Nombre De Usuario:"
        '
        'IdVendedorLabel
        '
        IdVendedorLabel.AutoSize = True
        IdVendedorLabel.Location = New System.Drawing.Point(32, 35)
        IdVendedorLabel.Name = "IdVendedorLabel"
        IdVendedorLabel.Size = New System.Drawing.Size(68, 13)
        IdVendedorLabel.TabIndex = 29
        IdVendedorLabel.Text = "Id Vendedor:"
        '
        'btnAplicar
        '
        Me.btnAplicar.Location = New System.Drawing.Point(167, 79)
        Me.btnAplicar.Name = "btnAplicar"
        Me.btnAplicar.Size = New System.Drawing.Size(75, 23)
        Me.btnAplicar.TabIndex = 9
        Me.btnAplicar.Text = "Aplicar"
        Me.btnAplicar.UseVisualStyleBackColor = True
        '
        'gbxOperaciones
        '
        Me.gbxOperaciones.Controls.Add(Me.rbtEliminar)
        Me.gbxOperaciones.Controls.Add(Me.rbtModificar)
        Me.gbxOperaciones.Controls.Add(Me.rbtAgregar)
        Me.gbxOperaciones.Controls.Add(Me.rbtListado)
        Me.gbxOperaciones.Controls.Add(Me.btnAplicar)
        Me.gbxOperaciones.Location = New System.Drawing.Point(140, 12)
        Me.gbxOperaciones.Name = "gbxOperaciones"
        Me.gbxOperaciones.Size = New System.Drawing.Size(469, 108)
        Me.gbxOperaciones.TabIndex = 13
        Me.gbxOperaciones.TabStop = False
        Me.gbxOperaciones.Text = "GroupBox1"
        '
        'rbtEliminar
        '
        Me.rbtEliminar.AutoSize = True
        Me.rbtEliminar.Location = New System.Drawing.Point(245, 55)
        Me.rbtEliminar.Name = "rbtEliminar"
        Me.rbtEliminar.Size = New System.Drawing.Size(117, 17)
        Me.rbtEliminar.TabIndex = 3
        Me.rbtEliminar.TabStop = True
        Me.rbtEliminar.Text = "Eliminar Un Usuario"
        Me.rbtEliminar.UseVisualStyleBackColor = True
        '
        'rbtModificar
        '
        Me.rbtModificar.AutoSize = True
        Me.rbtModificar.Location = New System.Drawing.Point(245, 19)
        Me.rbtModificar.Name = "rbtModificar"
        Me.rbtModificar.Size = New System.Drawing.Size(153, 17)
        Me.rbtModificar.TabIndex = 2
        Me.rbtModificar.TabStop = True
        Me.rbtModificar.Text = "Modificar Datos de Usuario"
        Me.rbtModificar.UseVisualStyleBackColor = True
        '
        'rbtAgregar
        '
        Me.rbtAgregar.AutoSize = True
        Me.rbtAgregar.Location = New System.Drawing.Point(29, 55)
        Me.rbtAgregar.Name = "rbtAgregar"
        Me.rbtAgregar.Size = New System.Drawing.Size(136, 17)
        Me.rbtAgregar.TabIndex = 1
        Me.rbtAgregar.TabStop = True
        Me.rbtAgregar.Text = "Agregar Nuevo Usuario"
        Me.rbtAgregar.UseVisualStyleBackColor = True
        '
        'rbtListado
        '
        Me.rbtListado.AutoSize = True
        Me.rbtListado.Location = New System.Drawing.Point(29, 19)
        Me.rbtListado.Name = "rbtListado"
        Me.rbtListado.Size = New System.Drawing.Size(178, 17)
        Me.rbtListado.TabIndex = 0
        Me.rbtListado.TabStop = True
        Me.rbtListado.Text = "Listado De Ususrios Registrados"
        Me.rbtListado.UseVisualStyleBackColor = True
        '
        'dgvUsuarios
        '
        Me.dgvUsuarios.AllowUserToAddRows = False
        Me.dgvUsuarios.AllowUserToDeleteRows = False
        Me.dgvUsuarios.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgvUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvUsuarios.Location = New System.Drawing.Point(40, 150)
        Me.dgvUsuarios.Name = "dgvUsuarios"
        Me.dgvUsuarios.ReadOnly = True
        Me.dgvUsuarios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvUsuarios.Size = New System.Drawing.Size(754, 220)
        Me.dgvUsuarios.TabIndex = 13
        '
        'txtNombres
        '
        Me.txtNombres.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuariosBindingSource, "Nombre", True))
        Me.txtNombres.Location = New System.Drawing.Point(143, 83)
        Me.txtNombres.Name = "txtNombres"
        Me.txtNombres.Size = New System.Drawing.Size(100, 20)
        Me.txtNombres.TabIndex = 16
        '
        'txtID
        '
        Me.txtID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuariosBindingSource, "IdUsuario", True))
        Me.txtID.Location = New System.Drawing.Point(345, 34)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(100, 20)
        Me.txtID.TabIndex = 18
        '
        'txtPassword
        '
        Me.txtPassword.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuariosBindingSource, "Contraseña", True))
        Me.txtPassword.Location = New System.Drawing.Point(397, 126)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(100, 20)
        Me.txtPassword.TabIndex = 20
        '
        'txtApellidos
        '
        Me.txtApellidos.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuariosBindingSource, "Apellidos", True))
        Me.txtApellidos.Location = New System.Drawing.Point(397, 87)
        Me.txtApellidos.Name = "txtApellidos"
        Me.txtApellidos.Size = New System.Drawing.Size(100, 20)
        Me.txtApellidos.TabIndex = 22
        '
        'txtNombUsuario
        '
        Me.txtNombUsuario.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuariosBindingSource, "NombreDeUsuario", True))
        Me.txtNombUsuario.Location = New System.Drawing.Point(143, 122)
        Me.txtNombUsuario.Name = "txtNombUsuario"
        Me.txtNombUsuario.Size = New System.Drawing.Size(100, 20)
        Me.txtNombUsuario.TabIndex = 24
        '
        'gbxDatosUsuario
        '
        Me.gbxDatosUsuario.Controls.Add(Me.btnMuestraOculta)
        Me.gbxDatosUsuario.Controls.Add(IdVendedorLabel)
        Me.gbxDatosUsuario.Controls.Add(Me.txtIdVendedor)
        Me.gbxDatosUsuario.Controls.Add(Me.txtTotalUsuarios)
        Me.gbxDatosUsuario.Controls.Add(Me.cboTAcceso)
        Me.gbxDatosUsuario.Controls.Add(Me.btnActualizar)
        Me.gbxDatosUsuario.Controls.Add(Me.btnEliminar)
        Me.gbxDatosUsuario.Controls.Add(Me.btnGuardar)
        Me.gbxDatosUsuario.Controls.Add(IdUsuarioLabel)
        Me.gbxDatosUsuario.Controls.Add(NombreLabel)
        Me.gbxDatosUsuario.Controls.Add(Me.txtNombUsuario)
        Me.gbxDatosUsuario.Controls.Add(Me.txtNombres)
        Me.gbxDatosUsuario.Controls.Add(NombreDeUsuarioLabel)
        Me.gbxDatosUsuario.Controls.Add(Me.txtApellidos)
        Me.gbxDatosUsuario.Controls.Add(Me.txtID)
        Me.gbxDatosUsuario.Controls.Add(ApellidosLabel)
        Me.gbxDatosUsuario.Controls.Add(ContraseñaLabel)
        Me.gbxDatosUsuario.Controls.Add(Me.txtPassword)
        Me.gbxDatosUsuario.Location = New System.Drawing.Point(62, 376)
        Me.gbxDatosUsuario.Name = "gbxDatosUsuario"
        Me.gbxDatosUsuario.Size = New System.Drawing.Size(641, 219)
        Me.gbxDatosUsuario.TabIndex = 25
        Me.gbxDatosUsuario.TabStop = False
        Me.gbxDatosUsuario.Text = "GroupBox1"
        '
        'btnMuestraOculta
        '
        Me.btnMuestraOculta.Location = New System.Drawing.Point(512, 125)
        Me.btnMuestraOculta.Name = "btnMuestraOculta"
        Me.btnMuestraOculta.Size = New System.Drawing.Size(75, 23)
        Me.btnMuestraOculta.TabIndex = 31
        Me.btnMuestraOculta.Text = "Mostrar"
        Me.btnMuestraOculta.UseVisualStyleBackColor = True
        '
        'txtIdVendedor
        '
        Me.txtIdVendedor.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuariosBindingSource, "IdVendedor", True))
        Me.txtIdVendedor.Location = New System.Drawing.Point(106, 32)
        Me.txtIdVendedor.Name = "txtIdVendedor"
        Me.txtIdVendedor.Size = New System.Drawing.Size(100, 20)
        Me.txtIdVendedor.TabIndex = 30
        '
        'txtTotalUsuarios
        '
        Me.txtTotalUsuarios.Location = New System.Drawing.Point(521, 30)
        Me.txtTotalUsuarios.Name = "txtTotalUsuarios"
        Me.txtTotalUsuarios.Size = New System.Drawing.Size(26, 20)
        Me.txtTotalUsuarios.TabIndex = 29
        '
        'cboTAcceso
        '
        Me.cboTAcceso.FormattingEnabled = True
        Me.cboTAcceso.Location = New System.Drawing.Point(499, 172)
        Me.cboTAcceso.Name = "cboTAcceso"
        Me.cboTAcceso.Size = New System.Drawing.Size(121, 21)
        Me.cboTAcceso.TabIndex = 28
        '
        'btnActualizar
        '
        Me.btnActualizar.Location = New System.Drawing.Point(387, 172)
        Me.btnActualizar.Name = "btnActualizar"
        Me.btnActualizar.Size = New System.Drawing.Size(75, 23)
        Me.btnActualizar.TabIndex = 27
        Me.btnActualizar.Text = "Actualizar"
        Me.btnActualizar.UseVisualStyleBackColor = True
        '
        'btnEliminar
        '
        Me.btnEliminar.Location = New System.Drawing.Point(219, 172)
        Me.btnEliminar.Name = "btnEliminar"
        Me.btnEliminar.Size = New System.Drawing.Size(75, 23)
        Me.btnEliminar.TabIndex = 26
        Me.btnEliminar.Text = "Eliminar"
        Me.btnEliminar.UseVisualStyleBackColor = True
        '
        'btnGuardar
        '
        Me.btnGuardar.Location = New System.Drawing.Point(49, 172)
        Me.btnGuardar.Name = "btnGuardar"
        Me.btnGuardar.Size = New System.Drawing.Size(75, 23)
        Me.btnGuardar.TabIndex = 25
        Me.btnGuardar.Text = "Guardar"
        Me.btnGuardar.UseVisualStyleBackColor = True
        '
        'btnOperacion
        '
        Me.btnOperacion.Location = New System.Drawing.Point(307, 624)
        Me.btnOperacion.Name = "btnOperacion"
        Me.btnOperacion.Size = New System.Drawing.Size(75, 23)
        Me.btnOperacion.TabIndex = 26
        Me.btnOperacion.Text = "btnOperacion"
        Me.btnOperacion.UseVisualStyleBackColor = True
        '
        'btnTerminar
        '
        Me.btnTerminar.Location = New System.Drawing.Point(462, 624)
        Me.btnTerminar.Name = "btnTerminar"
        Me.btnTerminar.Size = New System.Drawing.Size(75, 23)
        Me.btnTerminar.TabIndex = 27
        Me.btnTerminar.Text = "Button2"
        Me.btnTerminar.UseVisualStyleBackColor = True
        '
        'lblTexto
        '
        Me.lblTexto.AutoSize = True
        Me.lblTexto.Location = New System.Drawing.Point(193, 123)
        Me.lblTexto.Name = "lblTexto"
        Me.lblTexto.Size = New System.Drawing.Size(39, 13)
        Me.lblTexto.TabIndex = 28
        Me.lblTexto.Text = "Label1"
        '
        'UsuariosBindingSource
        '
        Me.UsuariosBindingSource.DataMember = "Usuarios"
        Me.UsuariosBindingSource.DataSource = Me.GFacHojillaDataSet
        '
        'GFacHojillaDataSet
        '
        Me.GFacHojillaDataSet.DataSetName = "GFacHojillaDataSet"
        Me.GFacHojillaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'UsuariosTableAdapter
        '
        Me.UsuariosTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ClientesTableAdapter = Nothing
        Me.TableAdapterManager.EntregasTableAdapter = Nothing
        Me.TableAdapterManager.MercaderíaTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = PrPapelitoFinal.GFacHojillaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.Usuarios1TableAdapter = Nothing
        Me.TableAdapterManager.UsuariosTableAdapter = Me.UsuariosTableAdapter
        Me.TableAdapterManager.VendedorTableAdapter = Nothing
        Me.TableAdapterManager.VentasTableAdapter = Nothing
        '
        'Usuarios1BindingSource
        '
        Me.Usuarios1BindingSource.DataMember = "Usuarios1"
        Me.Usuarios1BindingSource.DataSource = Me.GFacHojillaDataSet
        '
        'Usuarios1TableAdapter
        '
        Me.Usuarios1TableAdapter.ClearBeforeFill = True
        '
        'frmListUsuario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(806, 728)
        Me.Controls.Add(Me.lblTexto)
        Me.Controls.Add(Me.btnTerminar)
        Me.Controls.Add(Me.btnOperacion)
        Me.Controls.Add(Me.gbxDatosUsuario)
        Me.Controls.Add(Me.dgvUsuarios)
        Me.Controls.Add(Me.gbxOperaciones)
        Me.Name = "frmListUsuario"
        Me.Text = "Guardar"
        Me.gbxOperaciones.ResumeLayout(False)
        Me.gbxOperaciones.PerformLayout()
        CType(Me.dgvUsuarios, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbxDatosUsuario.ResumeLayout(False)
        Me.gbxDatosUsuario.PerformLayout()
        CType(Me.UsuariosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GFacHojillaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Usuarios1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GFacHojillaDataSet As GFacHojillaDataSet
    Friend WithEvents UsuariosBindingSource As BindingSource
    Friend WithEvents UsuariosTableAdapter As GFacHojillaDataSetTableAdapters.UsuariosTableAdapter
    Friend WithEvents TableAdapterManager As GFacHojillaDataSetTableAdapters.TableAdapterManager
    Friend WithEvents btnAplicar As Button
    Friend WithEvents gbxOperaciones As GroupBox
    Friend WithEvents rbtEliminar As RadioButton
    Friend WithEvents rbtModificar As RadioButton
    Friend WithEvents rbtAgregar As RadioButton
    Friend WithEvents rbtListado As RadioButton
    Friend WithEvents dgvUsuarios As DataGridView
    Friend WithEvents txtNombres As TextBox
    Friend WithEvents txtID As TextBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtApellidos As TextBox
    Friend WithEvents txtNombUsuario As TextBox
    Friend WithEvents gbxDatosUsuario As GroupBox
    Friend WithEvents btnActualizar As Button
    Friend WithEvents btnEliminar As Button
    Friend WithEvents btnGuardar As Button
    Friend WithEvents cboTAcceso As ComboBox
    Friend WithEvents txtTotalUsuarios As TextBox
    Friend WithEvents txtIdVendedor As TextBox
    Friend WithEvents btnOperacion As Button
    Friend WithEvents btnTerminar As Button
    Friend WithEvents lblTexto As Label
    Friend WithEvents btnMuestraOculta As Button
    Friend WithEvents Usuarios1BindingSource As BindingSource
    Friend WithEvents Usuarios1TableAdapter As GFacHojillaDataSetTableAdapters.Usuarios1TableAdapter
End Class
