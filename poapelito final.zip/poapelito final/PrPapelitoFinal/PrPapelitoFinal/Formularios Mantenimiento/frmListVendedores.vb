﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmListVendedores
    Private dv As New DataView




    Private Sub VendedorBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.VendedorBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.GFacHojillaDataSet)


    End Sub

    Private Sub frmListVendedores_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'GFacHojillaDataSet.Vendedor' Puede moverla o quitarla según sea necesario.
        Me.VendedorTableAdapter.Fill(Me.GFacHojillaDataSet.Vendedor)

    End Sub
    Private Sub AgregarVendedor()
        'Declarando un objeto de tipo formulario para instanciar a la clase
        Dim frmAgregarVendedor As frmAgregarVendedor = New frmAgregarVendedor()
        'Indicamos ahora que este objeto formulario es hijo del formulario principal (me), con el que estamos trabajando
        frmAgregarVendedor.Show()
    End Sub
    Private Sub BorrarVendedor()
        'Declarando un objeto de tipo formulario para instanciar a la clase
        Dim frmBorrarVendedor As frmBorrarVendedor = New frmBorrarVendedor()
        'Indicamos ahora que este objeto formulario es hijo del formulario principal (me), con el que estamos trabajando
        frmBorrarVendedor.Show()
    End Sub
    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        AgregarVendedor()

    End Sub
    Private Sub btnMuestrAlt_Click(sender As Object, e As EventArgs) Handles btnMuestrAlt.Click
        Try
            'Declarando variables (Cadena de Conexión, Adaptador de Datos y DataSet)
            Dim conex As New SqlConnection("Data Source=DESKTOP-5G7MSS4\SQLEXPRESS;Initial Catalog=GFacHojilla;Integrated Security=SSPI;")
            'Consulta a la Tabla de la B.D.
            Dim da As New SqlDataAdapter("Select * From Vendedor", conex)
            Dim ds As New DataSet
            'Cargamos la Tabla de Datos dentro del DataGridView
            da.Fill(ds)
            dv.Table = ds.Tables(0)
            DataGridView1.DataSource = dv
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
    End Sub

    Private Sub txtApellidos_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnBorrar_Click(sender As Object, e As EventArgs) Handles btnBorrar.Click
        BorrarVendedor()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class
